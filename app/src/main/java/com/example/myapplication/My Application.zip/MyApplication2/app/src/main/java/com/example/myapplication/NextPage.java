package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;

public class NextPage extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
    }
}
