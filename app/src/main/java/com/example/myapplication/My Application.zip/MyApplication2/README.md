"# ANDROID_Learn_Example"

### Source document:

#### https://www.javatpoint.com/android-tutorial

all document and example follow javatpoint.com to pratice paticially android skill.
